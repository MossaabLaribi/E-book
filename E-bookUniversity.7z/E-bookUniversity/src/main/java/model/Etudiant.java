package model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Etudiant implements Serializable {
	
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	public int matricul;
	public String nom;
	public String prenom;
	public String nom_utilisateur;
	public String password;
	public boolean bonus; 
	
	
	public Etudiant() {
		// TODO Auto-generated constructor stub
	}
	
	public int getMatricul() {
		return matricul;
	}
	public String getNom() {
		return nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public String getNom_utilisateur() {
		return nom_utilisateur;
	}
	public String getPassword() {
		return password;
	}
	public boolean getBonus() {
		return bonus;
	}
	public void setMatricul(int matricul) {
		this.matricul = matricul;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setNom_utilisateur(String nom_utilisateur) {
		this.nom_utilisateur = nom_utilisateur;
	}
	public void setBonus(boolean bonus) {
		this.bonus = bonus;
	}
	

}
